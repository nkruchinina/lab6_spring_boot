package edu.ntudp.sau.kruchinina.javaspringbootlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringBootLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringBootLabApplication.class, args);
	}

}
